package com.vehiclemanagement.service;

import com.vehiclemanagement.entity.Booking;
import com.vehiclemanagement.repository.BookingRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookingService {
    private final BookingRepository repository;
    public BookingService(BookingRepository repository) { this.repository = repository; }
    public List<Booking> getAll() { return repository.findAll(); }
    public Booking getById(Long id) { return repository.findById(id).orElseThrow(); }
    public Booking save(Booking booking) { return repository.save(booking); }
    public void delete(Long id) { repository.deleteById(id); }
}
