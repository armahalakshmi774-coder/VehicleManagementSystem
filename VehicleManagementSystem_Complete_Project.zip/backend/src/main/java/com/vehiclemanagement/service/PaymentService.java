package com.vehiclemanagement.service;

import com.vehiclemanagement.entity.Payment;
import com.vehiclemanagement.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PaymentService {
    private final PaymentRepository repository;
    public PaymentService(PaymentRepository repository) { this.repository = repository; }
    public List<Payment> getAll() { return repository.findAll(); }
    public Payment getById(Long id) { return repository.findById(id).orElseThrow(); }
    public Payment save(Payment payment) { return repository.save(payment); }
    public void delete(Long id) { repository.deleteById(id); }
}
