package com.vehiclemanagement.service;

import com.vehiclemanagement.entity.Vehicle;
import com.vehiclemanagement.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class VehicleService {
    private final VehicleRepository repository;
    public VehicleService(VehicleRepository repository) { this.repository = repository; }
    public List<Vehicle> getAll() { return repository.findAll(); }
    public Vehicle getById(Long id) { return repository.findById(id).orElseThrow(); }
    public Vehicle save(Vehicle vehicle) { return repository.save(vehicle); }
    public void delete(Long id) { repository.deleteById(id); }
}
